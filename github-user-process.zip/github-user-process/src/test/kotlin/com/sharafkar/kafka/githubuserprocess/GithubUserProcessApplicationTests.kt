package com.sharafkar.kafka.githubuserprocess

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GithubUserProcessApplicationTests {

	@Test
	fun contextLoads() {
	}

}
