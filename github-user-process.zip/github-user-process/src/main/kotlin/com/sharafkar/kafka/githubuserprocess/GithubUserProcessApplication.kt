package com.sharafkar.kafka.githubuserprocess

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class GithubUserProcessApplication

fun main(args: Array<String>) {
	runApplication<GithubUserProcessApplication>(*args)
}
