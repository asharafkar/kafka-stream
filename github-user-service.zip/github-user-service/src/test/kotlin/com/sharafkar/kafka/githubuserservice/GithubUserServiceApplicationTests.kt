package com.sharafkar.kafka.githubuserservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GithubUserServiceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
