package com.sharafkar.kafka.githubuserservice

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class GithubUserServiceApplication

fun main(args: Array<String>) {
	runApplication<GithubUserServiceApplication>(*args)
}
