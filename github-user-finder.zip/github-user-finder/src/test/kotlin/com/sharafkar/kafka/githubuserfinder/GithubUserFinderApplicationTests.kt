package com.sharafkar.kafka.githubuserfinder

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GithubUserFinderApplicationTests {

	@Test
	fun contextLoads() {
	}

}
