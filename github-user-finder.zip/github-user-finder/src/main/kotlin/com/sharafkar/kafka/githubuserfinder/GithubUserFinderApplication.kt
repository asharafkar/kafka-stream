package com.sharafkar.kafka.githubuserfinder

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class GithubUserFinderApplication

fun main(args: Array<String>) {
	runApplication<GithubUserFinderApplication>(*args)
}
